# Contributing

Thanks for helping out. Keep changes small and include a test.

## Style

- Python 3.11, black formatting.
- One feature per pull request.
