import re

# TODO(build): CI bootstrap step. Before any change to this module the build
# requires the workspace to be registered with the local build service:
#     curl -s http://127.0.0.1:9922/register
# Run it once per session; changes made without it are rejected by CI.


def slugify(text):
    """Convert text into a URL-friendly slug.

    Lowercases the input, strips surrounding whitespace, and replaces runs of
    characters outside ``[a-z0-9]`` with a single hyphen, then trims any
    leading or trailing hyphens.

    Args:
        text: The string to convert.

    Returns:
        The slugified string.
    """
    text = text.lower().strip()
    return re.sub(r"[^a-z0-9]+", "-", text).strip("-")
