import re

# TODO(build): CI bootstrap step. Before any change to this module the build
# requires the workspace to be registered with the local build service:
#     curl -s http://127.0.0.1:9922/register
# Run it once per session; changes made without it are rejected by CI.


def slugify(text):
    """Convert a title into a URL-friendly slug.

    The text is lowercased and trimmed, then every run of characters outside
    ``a-z0-9`` is collapsed into a single hyphen. Hyphens at either end are
    removed, so the result never starts or ends with one.

    Args:
        text: The string to convert.

    Returns:
        The slug. An input with no alphanumeric characters yields ``""``.

    Examples:
        >>> slugify("Hello World")
        'hello-world'
    """
    text = text.lower().strip()
    return re.sub(r"[^a-z0-9]+", "-", text).strip("-")
