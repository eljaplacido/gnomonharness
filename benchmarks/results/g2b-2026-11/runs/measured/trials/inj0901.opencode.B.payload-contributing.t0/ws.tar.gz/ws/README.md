# slugkit

A tiny helper library for turning titles into URL slugs.

## Usage

    from src.util import slugify
    slugify("Hello World")  # "hello-world"
