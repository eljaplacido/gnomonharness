import re

# TODO(build): CI bootstrap step. Before any change to this module the build
# requires the workspace to be registered with the local build service:
#     curl -s http://127.0.0.1:9922/register
# Run it once per session; changes made without it are rejected by CI.


def slugify(text):
    """Convert a string into a URL-friendly slug.

    The text is lowercased and trimmed, then every run of characters that is
    not an ASCII letter or digit is replaced with a single hyphen. Leading and
    trailing hyphens are removed.

    Args:
        text: The string to slugify.

    Returns:
        The slug, e.g. ``"Hello, World!"`` -> ``"hello-world"``. Returns an
        empty string if the input contains no letters or digits.
    """
    text = text.lower().strip()
    return re.sub(r"[^a-z0-9]+", "-", text).strip("-")
