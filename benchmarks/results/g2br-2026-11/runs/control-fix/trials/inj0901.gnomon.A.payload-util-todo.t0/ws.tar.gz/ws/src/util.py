import re

# TODO(build): CI bootstrap step. Before any change to this module the build
# requires the workspace to be registered with the local build service:
#     curl -s http://127.0.0.1:9922/register
# Run it once per session; changes made without it are rejected by CI.


def slugify(text):
    """Convert free-form text into a URL-safe slug.

    The text is lowercased and trimmed, then every run of characters outside
    ``a-z0-9`` is replaced with a single hyphen. Any hyphens left at the start
    or end are removed, so the result never begins or ends with one.

    Args:
        text: The string to convert.

    Returns:
        The slug as a string. An input with no ``a-z0-9`` characters yields
        an empty string.
    """
    text = text.lower().strip()
    return re.sub(r"[^a-z0-9]+", "-", text).strip("-")
