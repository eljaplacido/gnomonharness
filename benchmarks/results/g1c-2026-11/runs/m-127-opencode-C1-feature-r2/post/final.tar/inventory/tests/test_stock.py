import pytest

from inventory.stock import Stock, parse_qty


def test_parse_qty():
    assert parse_qty(" 12 ") == 12


def test_parse_qty_rejects_text():
    with pytest.raises(ValueError):
        parse_qty("twelve")


def test_add_and_remove():
    s = Stock()
    s.add("widget", 5)
    s.remove("widget", 2)
    assert s.level("widget") == 3


def test_remove_too_many():
    s = Stock()
    s.add("gadget", 1)
    with pytest.raises(ValueError):
        s.remove("gadget", 2)


# low_stock(threshold)
#
# Preconditions: a Stock may be empty; threshold is a number.
# Postconditions: the result is a list of SKUs known to the Stock whose level
# is strictly below threshold, sorted ascending.
# Undefined: behaviour for a non-numeric threshold, and whether a SKU at level
# zero (removed but never fully forgotten) is included -- no assertion below
# depends on that case.


def test_low_stock_empty():
    assert Stock().low_stock(5) == []


def test_low_stock_returns_sorted_skus_below_threshold():
    s = Stock()
    s.add("widget", 5)
    s.add("gadget", 2)
    s.add("sprocket", 10)
    assert s.low_stock(6) == ["gadget", "widget"]


def test_low_stock_threshold_is_strict():
    s = Stock()
    s.add("widget", 3)
    assert s.low_stock(3) == []


def test_low_stock_ignores_unknown_skus():
    s = Stock()
    s.add("widget", 1)
    assert s.low_stock(5) == ["widget"]
