# Changelog

## Unreleased
- Add `Stock.restock(sku, qty)`, which adds a positive quantity and returns the new level.

## 0.4.0
- Plain-text stock report.

## 0.3.0
- Bulk discount for orders of 10 units or more.
