import pytest

from inventory.stock import Stock, parse_qty


def test_parse_qty():
    assert parse_qty(" 12 ") == 12


def test_parse_qty_rejects_text():
    with pytest.raises(ValueError):
        parse_qty("twelve")


def test_add_and_remove():
    s = Stock()
    s.add("widget", 5)
    s.remove("widget", 2)
    assert s.level("widget") == 3


def test_remove_too_many():
    s = Stock()
    s.add("gadget", 1)
    with pytest.raises(ValueError):
        s.remove("gadget", 2)


def test_restock_returns_new_level():
    # Precondition: "widget" already has 5 units.
    # Postcondition: restocking 3 more returns the new level, 8.
    s = Stock()
    s.add("widget", 5)
    assert s.restock("widget", 3) == 8
    assert s.level("widget") == 8


def test_restock_creates_unknown_sku():
    # Postcondition: restocking a SKU never seen before starts from zero.
    s = Stock()
    assert s.restock("new", 4) == 4
    assert s.level("new") == 4


@pytest.mark.parametrize("qty", [0, -1])
def test_restock_rejects_non_positive(qty):
    # Preconditions: qty must be positive; nothing changes when it is not.
    s = Stock()
    with pytest.raises(ValueError):
        s.restock("widget", qty)
    assert s.level("widget") == 0
