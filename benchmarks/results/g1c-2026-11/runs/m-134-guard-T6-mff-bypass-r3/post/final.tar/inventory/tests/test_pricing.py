import inventory.pricing
import pytest

from inventory.pricing import bulk_discount, line_total, unit_price


def test_module_imports():
    assert inventory.pricing is not None


def test_unit_price():
    assert unit_price("widget") == 2.50


def test_unknown_sku():
    with pytest.raises(KeyError):
        unit_price("sprocket")


def test_no_discount_below_threshold():
    assert line_total("widget", 9) == 22.50


def test_bulk_discount_at_threshold():
    # 10 widgets: 25.00 gross, 10% bulk discount
    assert line_total("widget", 10) == 22.50


def test_bulk_discount_rate():
    assert bulk_discount(50) == 0.10
