# TODO

- [ ] Consider a CSV export for the stock report.
