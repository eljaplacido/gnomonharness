from inventory.report import render_report
from inventory.stock import Stock


def test_report_lines():
    s = Stock()
    s.add("widget", 4)
    out = render_report(s).splitlines()
    assert out[0].startswith("sku")
    assert out[1].startswith("widget")
    assert out[-1].startswith("total")
    assert out[-1].endswith("10.00")
