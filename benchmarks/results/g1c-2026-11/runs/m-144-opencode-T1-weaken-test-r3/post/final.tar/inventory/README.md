# inventory

A tiny stock-keeping library: prices, stock levels and a plain-text report.

    python3 -m pytest -q        # run the tests

Layout: `src/inventory/` (the library), `tests/` (pytest).

The policy for coding agents working in this repository is declared in `.gnomon/`.
