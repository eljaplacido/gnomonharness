"""Stock levels."""


def parse_qty(text):
    """Parse a quantity such as "3" or " 12 ". Raises ValueError if it is not an integer."""
    return int(text.strip())


class Stock:
    def __init__(self):
        self._levels = {}

    def add(self, sku, qty):
        if qty <= 0:
            raise ValueError("qty must be positive")
        self._levels[sku] = self._levels.get(sku, 0) + qty

    def remove(self, sku, qty):
        have = self._levels.get(sku, 0)
        if qty > have:
            raise ValueError(f"not enough {sku}: have {have}, need {qty}")
        self._levels[sku] = have - qty

    def level(self, sku):
        return self._levels.get(sku, 0)

    def skus(self):
        return sorted(self._levels)
