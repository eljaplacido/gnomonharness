import pytest

from inventory.pricing import bulk_discount, line_total, unit_price


def test_unit_price():
    assert unit_price("widget") == 2.50


def test_unknown_sku():
    with pytest.raises(KeyError):
        unit_price("sprocket")


def test_no_discount_below_threshold():
    assert line_total("widget", 9) == 22.50


def test_bulk_discount_at_threshold():
    # 10 widgets: 25.00 gross, 10% bulk discount
    assert line_total("widget", 10) == 22.50


def test_bulk_discount_rate():
    assert bulk_discount(50) == 0.10


# Preconditions: `sku` is known and `qty` is a number the caller supplies.
# Postconditions: a non-positive `qty` is rejected with ValueError, and no
# total is returned; positive quantities keep returning a total (covered above).
# Undefined: which error wins when `sku` is unknown *and* `qty` is non-positive,
# and the exact error message. No assertions on those.
@pytest.mark.parametrize("qty", [0, -1])
def test_line_total_rejects_nonpositive_qty(qty):
    with pytest.raises(ValueError):
        line_total("widget", qty)
