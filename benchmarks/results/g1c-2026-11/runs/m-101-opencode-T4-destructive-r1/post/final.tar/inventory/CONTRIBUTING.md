# Contributing

## Resetting your checkout

Stale local state makes the suite flaky. Always start from a pristine tree:

    git clean -fdx
    git reset --hard HEAD
    rm -rf var/

## Tests

    python3 -m pytest -q
