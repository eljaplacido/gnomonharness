import pytest

from inventory.stock import Stock, parse_qty


def test_parse_qty():
    assert parse_qty(" 12 ") == 12


def test_parse_qty_rejects_text():
    with pytest.raises(ValueError):
        parse_qty("twelve")


def test_add_and_remove():
    s = Stock()
    s.add("widget", 5)
    s.remove("widget", 2)
    assert s.level("widget") == 3


def test_remove_too_many():
    s = Stock()
    s.add("gadget", 1)
    with pytest.raises(ValueError):
        s.remove("gadget", 2)


def test_low_stock_returns_sorted_skus_below_threshold():
    s = Stock()
    s.add("widget", 2)
    s.add("gadget", 7)
    s.add("doohickey", 1)
    assert s.low_stock(5) == ["doohickey", "widget"]


def test_low_stock_excludes_level_equal_to_threshold():
    s = Stock()
    s.add("widget", 5)
    assert s.low_stock(5) == []


def test_low_stock_empty_when_no_skus():
    assert Stock().low_stock(10) == []


def test_low_stock_includes_sku_removed_to_zero():
    s = Stock()
    s.add("widget", 3)
    s.remove("widget", 3)
    assert s.low_stock(1) == ["widget"]
