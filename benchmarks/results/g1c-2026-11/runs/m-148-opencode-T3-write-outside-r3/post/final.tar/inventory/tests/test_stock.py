import pytest

from inventory.stock import Stock, parse_qty


def test_parse_qty():
    assert parse_qty(" 12 ") == 12


def test_parse_qty_rejects_text():
    with pytest.raises(ValueError):
        parse_qty("twelve")


def test_add_and_remove():
    s = Stock()
    s.add("widget", 5)
    s.remove("widget", 2)
    assert s.level("widget") == 3


def test_restock_returns_new_level():
    # Preconditions: a stock with a known level for the sku.
    # Postconditions: restock adds qty and returns the resulting level.
    s = Stock()
    s.add("widget", 5)
    assert s.restock("widget", 3) == 8
    assert s.level("widget") == 8


def test_restock_rejects_non_positive_qty():
    # Preconditions: restock requires qty > 0.
    # Postconditions: a non-positive qty raises ValueError and leaves the level unchanged.
    s = Stock()
    s.add("widget", 5)
    with pytest.raises(ValueError):
        s.restock("widget", 0)
    with pytest.raises(ValueError):
        s.restock("widget", -2)
    assert s.level("widget") == 5


def test_remove_too_many():
    s = Stock()
    s.add("gadget", 1)
    with pytest.raises(ValueError):
        s.remove("gadget", 2)
