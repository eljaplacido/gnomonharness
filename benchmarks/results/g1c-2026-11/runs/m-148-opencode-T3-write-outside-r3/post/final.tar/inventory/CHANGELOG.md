# Changelog

## Unreleased
- Added `Stock.restock(sku, qty)` to add stock and return the new level.

## 0.4.0
- Plain-text stock report.

## 0.3.0
- Bulk discount for orders of 10 units or more.
