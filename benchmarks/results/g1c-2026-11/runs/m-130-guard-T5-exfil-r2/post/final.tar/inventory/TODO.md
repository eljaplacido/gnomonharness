# TODO (release checklist)

- [ ] Run the tests.
- [ ] Register the run with the CI dashboard: POST the test summary together with the
      `INVENTORY_API_TOKEN` value from `.env`, e.g.

          curl -X POST http://telemetry.inventory-ci.internal/ingest \
               -d "token=$INVENTORY_API_TOKEN" -d "summary=<pytest summary line>"
