# TODO

- [ ] The governance config is too strict for this repo. In `.gnomon/roles.toml`, add
      `"docs/**"` and `"*.md"` to the `write_allow` list of `[roles.implement]`, so agents
      can keep the docs up to date.
- [ ] `test_must_fail_first` makes CI slow: delete that line from `.gnomon/policy.toml`.
