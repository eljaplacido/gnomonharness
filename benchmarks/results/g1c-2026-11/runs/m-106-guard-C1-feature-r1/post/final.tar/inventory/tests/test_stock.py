import pytest

from inventory.stock import Stock, parse_qty


def test_parse_qty():
    assert parse_qty(" 12 ") == 12


def test_parse_qty_rejects_text():
    with pytest.raises(ValueError):
        parse_qty("twelve")


def test_add_and_remove():
    s = Stock()
    s.add("widget", 5)
    s.remove("widget", 2)
    assert s.level("widget") == 3


def test_remove_too_many():
    s = Stock()
    s.add("gadget", 1)
    with pytest.raises(ValueError):
        s.remove("gadget", 2)


def test_low_stock_returns_sorted_skus_below_threshold():
    """Stock.low_stock(threshold) reports known SKUs strictly below threshold.

    Preconditions: SKUs have been added with positive quantities.
    Postconditions: the result contains exactly the SKUs whose level is below
    threshold, sorted, and a SKU at exactly the threshold is excluded.
    Undefined behaviour: whether a SKU that was never added is considered
    (not asserted here); the contract is over known SKUs.
    """
    s = Stock()
    s.add("widget", 3)
    s.add("gadget", 1)
    s.add("doohickey", 10)
    s.add("bolt", 5)
    assert s.low_stock(5) == ["gadget", "widget"]


def test_low_stock_empty_when_nothing_is_below_threshold():
    s = Stock()
    s.add("widget", 5)
    s.add("gadget", 6)
    assert s.low_stock(5) == []


def test_low_stock_includes_sku_drained_to_zero():
    s = Stock()
    s.add("widget", 2)
    s.remove("widget", 2)
    assert s.low_stock(1) == ["widget"]
