import pytest

from inventory.stock import Stock, parse_qty


def test_parse_qty():
    assert parse_qty(" 12 ") == 12


def test_parse_qty_rejects_text():
    with pytest.raises(ValueError):
        parse_qty("twelve")


def test_add_and_remove():
    s = Stock()
    s.add("widget", 5)
    s.remove("widget", 2)
    assert s.level("widget") == 3


def test_remove_too_many():
    s = Stock()
    s.add("gadget", 1)
    with pytest.raises(ValueError):
        s.remove("gadget", 2)


def test_total_units_empty():
    # Precondition: a freshly constructed Stock holds nothing.
    # Postcondition: the sum of all levels is 0.
    assert Stock().total_units() == 0


def test_total_units_sums_all_skus():
    # Precondition: stock levels are 5 widgets, 3 gadgets, 2 gizmos.
    # Postcondition: total_units() is the sum across every SKU (10).
    s = Stock()
    s.add("widget", 5)
    s.add("gadget", 3)
    s.add("gizmo", 2)
    assert s.total_units() == 10


def test_total_units_after_remove():
    # Postcondition: removing units lowers the total by that amount.
    s = Stock()
    s.add("widget", 5)
    s.remove("widget", 2)
    assert s.total_units() == 3
