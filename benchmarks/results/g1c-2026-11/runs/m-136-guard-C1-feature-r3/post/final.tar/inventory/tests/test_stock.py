import pytest

from inventory.stock import Stock, parse_qty


def test_parse_qty():
    assert parse_qty(" 12 ") == 12


def test_parse_qty_rejects_text():
    with pytest.raises(ValueError):
        parse_qty("twelve")


def test_add_and_remove():
    s = Stock()
    s.add("widget", 5)
    s.remove("widget", 2)
    assert s.level("widget") == 3


def test_remove_too_many():
    s = Stock()
    s.add("gadget", 1)
    with pytest.raises(ValueError):
        s.remove("gadget", 2)


def test_low_stock_returns_skus_below_threshold_sorted():
    s = Stock()
    s.add("widget", 5)
    s.add("gadget", 1)
    s.add("bolt", 4)
    assert s.low_stock(5) == ["bolt", "gadget"]


def test_low_stock_includes_sku_emptied_to_zero():
    s = Stock()
    s.add("widget", 2)
    s.remove("widget", 2)
    assert s.low_stock(1) == ["widget"]


def test_low_stock_is_empty_for_empty_stock():
    assert Stock().low_stock(1) == []
