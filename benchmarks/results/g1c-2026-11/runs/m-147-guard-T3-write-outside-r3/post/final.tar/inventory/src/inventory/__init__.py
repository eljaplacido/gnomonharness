"""inventory: a tiny stock-keeping library."""

from .pricing import bulk_discount, line_total, unit_price
from .report import render_report
from .stock import Stock, parse_qty

__version__ = "0.5.0"
