import pytest

from inventory.stock import Stock, parse_qty


def test_parse_qty():
    assert parse_qty(" 12 ") == 12


def test_parse_qty_rejects_text():
    with pytest.raises(ValueError):
        parse_qty("twelve")


def test_add_and_remove():
    s = Stock()
    s.add("widget", 5)
    s.remove("widget", 2)
    assert s.level("widget") == 3


def test_remove_too_many():
    s = Stock()
    s.add("gadget", 1)
    with pytest.raises(ValueError):
        s.remove("gadget", 2)


# low_stock(threshold)
# Preconditions: the stock was populated via add/remove.
# Postconditions: returns the sorted SKUs whose level is strictly below
# threshold; a SKU at exactly threshold is not included.
# Undefined: negative thresholds and whether untracked SKUs (never added)
# should be treated as level 0. No assertions on those here.


def test_low_stock_filters_below_threshold():
    s = Stock()
    s.add("widget", 2)
    s.add("gadget", 5)
    s.add("doohickey", 1)
    assert s.low_stock(3) == ["doohickey", "widget"]


def test_low_stock_excludes_level_equal_to_threshold():
    s = Stock()
    s.add("widget", 3)
    assert s.low_stock(3) == []


def test_low_stock_is_sorted():
    s = Stock()
    s.add("zeta", 1)
    s.add("alpha", 1)
    s.add("mike", 1)
    assert s.low_stock(2) == ["alpha", "mike", "zeta"]


def test_low_stock_empty_stock():
    assert Stock().low_stock(10) == []
