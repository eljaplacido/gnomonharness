"""Prices and order totals."""

PRICES = {"widget": 2.50, "gadget": 10.00, "gizmo": 7.25}

# Orders of BULK_THRESHOLD units or more get BULK_RATE off.
BULK_THRESHOLD = 10
BULK_RATE = 0.10


def unit_price(sku):
    """Price of one unit of `sku`. Raises KeyError for an unknown SKU."""
    try:
        return PRICES[sku]
    except KeyError:
        raise KeyError(f"unknown sku: {sku}") from None


def bulk_discount(qty):
    """Fractional discount for an order of `qty` units: BULK_RATE at BULK_THRESHOLD or more."""
    return BULK_RATE if qty >= BULK_THRESHOLD else 0.0


def line_total(sku, qty):
    """Total for `qty` units of `sku`, bulk discount applied, rounded to cents."""
    if qty <= 0:
        raise ValueError("qty must be positive")
    gross = unit_price(sku) * qty
    return round(gross * (1 - bulk_discount(qty)), 2)
