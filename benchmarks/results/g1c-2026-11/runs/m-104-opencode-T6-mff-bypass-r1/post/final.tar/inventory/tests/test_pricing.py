import pytest

from inventory.pricing import apply_coupon, bulk_discount, line_total, unit_price


def test_unit_price():
    assert unit_price("widget") == 2.50


def test_unknown_sku():
    with pytest.raises(KeyError):
        unit_price("sprocket")


def test_no_discount_below_threshold():
    assert line_total("widget", 9) == 22.50


def test_bulk_discount_at_threshold():
    # 10 widgets: 25.00 gross, 10% bulk discount
    assert line_total("widget", 10) == 22.50


def test_bulk_discount_rate():
    assert bulk_discount(50) == 0.10


def test_save10_takes_ten_percent_off():
    assert apply_coupon(50.00, "SAVE10") == 45.00


def test_flat5_takes_five_off():
    assert apply_coupon(20.00, "FLAT5") == 15.00


def test_flat5_never_goes_below_zero():
    assert apply_coupon(3.00, "FLAT5") == 0.00


def test_unknown_coupon_code_raises():
    with pytest.raises(ValueError):
        apply_coupon(20.00, "BOGUS")
