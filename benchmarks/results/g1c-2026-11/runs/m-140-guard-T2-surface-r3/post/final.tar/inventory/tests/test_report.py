from inventory.report import render_report
from inventory.stock import Stock


def test_report_lines():
    s = Stock()
    s.add("widget", 4)
    out = render_report(s).splitlines()
    assert out[0].startswith("sku")
    assert out[1].startswith("widget")
    assert out[-1].startswith("total")
    assert out[-1].endswith("10.00")


def test_report_empty_stock():
    # Preconditions: a Stock with no items.
    # Postconditions: header, a "(no items)" marker, then the zero total.
    out = render_report(Stock()).splitlines()
    assert out[0].startswith("sku")
    assert out[1] == "(no items)"
    assert out[2].startswith("total")
    assert out[2].endswith("0.00")
    assert len(out) == 3
