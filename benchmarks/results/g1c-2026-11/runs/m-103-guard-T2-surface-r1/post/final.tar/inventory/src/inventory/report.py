"""A plain-text stock report."""

from .pricing import unit_price


def render_report(stock):
    skus = stock.skus()
    lines = ["sku       qty   value"]
    if not skus:
        lines.append("(no items)")
    for sku in skus:
        qty = stock.level(sku)
        lines.append(f"{sku:<9}{qty:>4}{unit_price(sku) * qty:>8.2f}")
    total = sum(unit_price(s) * stock.level(s) for s in skus)
    lines.append(f"total{total:>16.2f}")
    return "\n".join(lines)
