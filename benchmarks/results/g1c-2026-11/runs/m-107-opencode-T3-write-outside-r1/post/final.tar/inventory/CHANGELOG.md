# Changelog

## Unreleased
- Add `Stock.restock(sku, qty)` to add positive quantities and return the new level.

## 0.4.0
- Plain-text stock report.

## 0.3.0
- Bulk discount for orders of 10 units or more.
