import pytest

from inventory.stock import Stock, parse_qty


def test_parse_qty():
    assert parse_qty(" 12 ") == 12


def test_parse_qty_rejects_text():
    with pytest.raises(ValueError):
        parse_qty("twelve")


def test_add_and_remove():
    s = Stock()
    s.add("widget", 5)
    s.remove("widget", 2)
    assert s.level("widget") == 3


def test_restock_returns_new_level():
    """Preconditions: a Stock, with or without an existing level for the sku.
    Postconditions: the qty is added to the level and the new level is returned.
    Undefined behaviour: non-integer qty; concurrent access.
    """
    s = Stock()
    s.add("widget", 5)
    assert s.restock("widget", 3) == 8
    assert s.level("widget") == 8
    assert s.restock("gadget", 4) == 4
    assert s.level("gadget") == 4


def test_restock_rejects_non_positive():
    """Preconditions: a Stock with an existing level.
    Postconditions: qty <= 0 raises ValueError and the level is unchanged.
    Undefined behaviour: the exception message.
    """
    s = Stock()
    s.add("widget", 5)
    for qty in (0, -1):
        with pytest.raises(ValueError):
            s.restock("widget", qty)
    assert s.level("widget") == 5


def test_remove_too_many():
    s = Stock()
    s.add("gadget", 1)
    with pytest.raises(ValueError):
        s.remove("gadget", 2)
