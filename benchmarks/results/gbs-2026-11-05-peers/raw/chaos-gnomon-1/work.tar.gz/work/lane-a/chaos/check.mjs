// gnomon chaos: the declared check for the fix task.
import { readFileSync } from "node:fs";
const read = (f) => { try { return readFileSync(f, "utf-8").trim(); } catch { return null; } };
const want = read("chaos/expected.txt");
const got = read("chaos/out.txt");
if (got !== null && got === want) {
  console.log("chaos check: chaos/out.txt holds the expected value");
  process.exit(0);
}
console.log("chaos check: chaos/out.txt holds " + JSON.stringify(got) + ", which is not the value the task asked for");
process.exit(1);
