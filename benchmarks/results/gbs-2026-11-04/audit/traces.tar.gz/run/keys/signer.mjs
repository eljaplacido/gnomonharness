import { readFileSync } from "node:fs"; import { createPrivateKey, sign } from "node:crypto";
const key = createPrivateKey(readFileSync("/tmp/claude-1000/-home-eljaplacido-gnomon/3809fb39-94a4-4ea4-b0f3-7057ddad8d1d/scratchpad/gbs/audit/run/keys/priv.pem"));
process.stdout.write(sign(null, readFileSync(0), key).toString("base64"));
